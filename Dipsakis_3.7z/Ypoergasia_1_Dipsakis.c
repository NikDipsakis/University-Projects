#include <stdio.h>

#define E 112524 // Σταθερά για τον αριθμό των εγγεγραμμένων ψηφοφόρων
#define N 5      // Σταθερά για τον αριθμό των συνδυασμών
#define K 30     // Σταθερά για τον συνολικό αριθμό εδρών
#define L 10     // Σταθερά για τον αριθμό εδρών που πάνε στο 1ο κόμμα
#define M 5      // Ελάχιστο ποσοστό για την απόκτηση εδρών

int main() {
    system("chcp 65001>nul");
    char partyNames[N][50]; // Όνομα κάθε συνδυασμού
    int votes[N];           // Ψήφοι που λαμβάνει κάθε συνδυασμός
    float percentages[N];   // Ποσοστά ψήφων κάθε συνδυασμού
    int seats[N] = {0};     // Έδρες κάθε συνδυασμού
    int totalVotes = 0, validVotes = 0;
    int blank, invalid;
    float electoralQuotient;
    int remainingSeats = K - L; // Έδρες προς κατανομή στην 2η διαδικασία
    float remainders[N] = {0}; // Υπόλοιπα από την πρώτη κατανομή για 2η κατανομή

    // Εισαγωγή δεδομένων για κάθε συνδυασμό
    for (int i = 0; i < N; i++) {
        printf("Εισάγετε το όνομα του %dου συνδυασμού: \n", i + 1);
        scanf("%s", partyNames[i]);
        printf("Εισάγετε τις ψήφους που έλαβε ο συνδυασμός %s: \n", partyNames[i]);
        scanf("%d", &votes[i]);
        totalVotes += votes[i];
    }

    printf("Από τους %d εγγεγραμμένους ψηφοφόρους εισάγετε τον αριθμό των λευκών ψηφοδελτίων: \n", E);
    scanf("%d", &blank);
    printf("Από τους %d εγγεγραμμένους εισάγετε τον αριθμό των άκυρων ψηφοδελτίων: \n", E);
    scanf("%d", &invalid);

    validVotes = totalVotes - (blank + invalid);

    // Υπολογισμός ποσοστών για κάθε συνδυασμό
    for (int i = 0; i < N; i++) {
        percentages[i] = (votes[i] / (float)validVotes) * 100;
        printf("Συνδυασμός: %s. Έλαβε: %d ψήφους. Ποσοστό: %.4f%%\n", partyNames[i], votes[i], percentages[i]);
    }

    
    electoralQuotient = 100.0 / (K - L);

    // 1η Κατανομή εδρών
    for (int i = 0; i < N; i++) {
        if (percentages[i] > M) { // Έλεγχος για το ελάχιστο ποσοστό M%
            seats[i] = (int)(percentages[i] / electoralQuotient);
            remainders[i] = percentages[i] - (seats[i] * electoralQuotient);
            remainingSeats -= seats[i];
        }
    }

    // Κατανομή των L εδρών στον νικητή αν υπάρχει 
    int winnerIndex = -1;
    float maxPercentage = 0;
    for (int i = 0; i < N; i++) {
        if (percentages[i] > 43) {
            if (percentages[i] > maxPercentage) {
                maxPercentage = percentages[i];
                winnerIndex = i;
            }
        }
    }
    if (winnerIndex != -1) { // Αν υπάρχει νικητής
        seats[winnerIndex] += L;
        printf("Ο συνδυασμός %s ανακηρύσσεται νικητής με ποσοστό %.4f%% και λαμβάνει BONUS %d έδρες.\n", partyNames[winnerIndex], percentages[winnerIndex], L);
    } else {
        printf("Δεν υπάρχει νικητής με ποσοστό άνω του 43%%. Απαιτείται δεύτερος γύρος.\n");
        return 0; // Τερματισμός προγράμματος εάν δεν υπάρχει νικητής
    }

    // 2η Κατανομή εδρών με βάση τα υπόλοιπα
    while (remainingSeats > 0) {
        int index = -1;
        float maxRemainder = 0;
        for (int i = 0; i < N; i++) {
            if (remainders[i] > maxRemainder) {
                index = i;
                maxRemainder = remainders[i];
            }
        }
        if (index != -1) {
            seats[index]++; // Προσθήκη μιας έδρας στον συνδυασμό με το μεγαλύτερο υπόλοιπο
            remainders[index] = 0; // Μηδενισμός του υπολοίπου για να μην επιλεγεί ξανά
            remainingSeats--;
        } else {
            break; // Έξοδος από την επανάληψη εάν δεν βρεθεί συνδυασμός για κατανομή έδρας
        }
    }

    // Εκτύπωση τελικών αποτελεσμάτων
    printf("\nΤελικά αποτελέσματα\n");
    for (int i = 0; i < N; i++) {
        printf("Συνδυασμός: %s. Έλαβε: %d ψήφους. Ποσοστό: %.4f%%. Έδρες: %d\n", partyNames[i], votes[i], percentages[i], seats[i]);
    }

    return 0;
}
