#include <stdio.h>
#include <string.h>

#define N 5  // Αριθμός των κομμάτων που συμμετέχουν

// Δομή για την αποθήκευση πληροφοριών κάθε κόμματος
typedef struct {
    int code;           // Μοναδικός κωδικός αριθμός κόμματος
    char name[50];      // Ονομασία κόμματος
    int votes;          // Πλήθος ψήφων στην Επικράτεια
    float percentage;   // Ποσοστό επί εγκύρων ψήφων
    int seats;          // Αριθμός εδρών
} party;

party election_results[N];  // Πίνακας για αποθήκευση αποτελεσμάτων
int votes_in_total = 0;     // Συνολικός αριθμός έγκυρων ψήφων

void initializeResults() {
    for (int i = 0; i < N; i++) {
        printf("Εισαγωγή στοιχείων για το %d κόμμα\n", i + 1);
        printf("Δωσε τον κωδικό αριθμό του κόμματος\n");
        scanf("%d", &election_results[i].code);
        printf("Δωσε το όνομα του κόμματος\n");
        scanf("%s", election_results[i].name);
        election_results[i].votes = 0;
        election_results[i].percentage = 0;
        election_results[i].seats = 0;
    }
}

void voteUpdate() {
    int votes;
    for (int i = 0; i < N; i++) {
        printf("Δωσε πλήθος έγκυρων ψήφων για το κόμμα με κωδικό %d\n", election_results[i].code);
        scanf("%d", &votes);
        if (votes >= 0) {
            election_results[i].votes += votes;
            votes_in_total += votes;
        } else {
            printf("Λάθος είσοδος. Οι ψήφοι δεν μπορούν να είναι αρνητικοί.\n");
        }
    }
}

int findWinningParty() {
    int maxVotes = 0, index = 0;
    for (int i = 0; i < N; i++) {
        if (election_results[i].votes > maxVotes) {
            maxVotes = election_results[i].votes;
            index = i;
        }
    }
    return index;
}

void seatDistribution() {
    int winnerIndex = findWinningParty();
    election_results[winnerIndex].seats += 50;  // Μπόνους εδρών για το νικητήριο κόμμα

    for (int i = 0; i < N; i++) {
        election_results[i].percentage = (float)election_results[i].votes / votes_in_total;
        if (i != winnerIndex) {  // Υπολογισμός εδρών για τα υπόλοιπα κόμματα
            election_results[i].seats += (int)(250 * election_results[i].percentage / (1 - election_results[winnerIndex].percentage));
        }
    }

    // Επανυπολογισμός εδρών για το νικητήριο κόμμα
    election_results[winnerIndex].seats += (int)(250 * election_results[winnerIndex].percentage / (1 - election_results[winnerIndex].percentage));

    // Διόρθωση συνολικού αριθμού εδρών αν χρειάζεται
    int totalSeats = 0;
    for (int i = 0; i < N; i++) {
        totalSeats += election_results[i].seats;
    }
    if (totalSeats > 300) {
        election_results[winnerIndex].seats -= totalSeats - 300;
    } else if (totalSeats < 300) {
        election_results[winnerIndex].seats += 300 - totalSeats;
    }

    // Εκτύπωση τελικών αποτελεσμάτων
    for (int i = 0; i < N; i++) {
        printf("Κωδικός: %d Ονομασία: %s Ποσοστό: %.2f%% Έδρες: %d\n", election_results[i].code, election_results[i].name, election_results[i].percentage * 100, election_results[i].seats);
    }
}

int main() {
    system("chcp 65001>nul");
    initializeResults();
    int choice;
    do {
        printf("Δώσε 1 για να εισάγεις τα αποτελέσματα εκλογικού τμήματος ή 2 για τα τελικά ποσοστά και την κατανομή εδρών.\n");
        scanf("%d", &choice);
        if (choice == 1) {
            voteUpdate();
        }
    } while (choice == 1);

    if (choice == 2) {
        seatDistribution();
    }

    return 0;
}
