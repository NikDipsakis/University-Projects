#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Ορισμός μνημονικών ονομάτων για τα ΑΛΗΘΕΣ και ΨΕΥΔΕΣ
#define TRUE 1
#define FALSE 0

// Ορισμός του κόμβου της λίστας
typedef struct node {
    char name[25];
    char data_type[6];
    struct node *next;
} node;

// Ορισμός του δείκτη σε λίστα
typedef node* node_pointer;

// Εμφανίζει τα περιεχόμενα μιας λίστας στην οθόνη
void show_list(node_pointer list) {
    printf("\nList:\n====================\n");
    while (list != NULL) {
        printf("Name: %s, Type: %s\n", list->name, list->data_type);
        list = list->next;
    }
    printf("====================\n");
}

// Αναζητεί αν μία μεταβλητή περιέχεται στη λίστα
int variable_in_list(node_pointer list, char* name) {
    while (list != NULL) {
        if (strcmp(list->name, name) == 0) {
            return TRUE;
        }
        list = list->next;
    }
    return FALSE;
}

// Προσθέτει μία νέα μεταβλητή στην πρώτη θέση της λίστας
void add_variable(node_pointer* list, char* name, char* data_type) {
    node_pointer new_node = (node_pointer)malloc(sizeof(node));
    strcpy(new_node->name, name);
    strcpy(new_node->data_type, data_type);
    new_node->next = *list;
    *list = new_node;
    printf("Variable %s added successfully\n", name);
}

// Προσθέτει μία μεταβλητή στη λίστα, αν δεν υπάρχει ήδη η μεταβλητή σε αυτήν
void add_variable_if_not_in_list(node_pointer* list, char* name, char* data_type) {
    if (!variable_in_list(*list, name)) {
        add_variable(list, name, data_type);
    } else {
        printf("Variable %s has already been declared\n", name);
    }
}

// Διαγραφή της λίστας και επιστροφή της μνήμης στο σύστημα
void delete_list(node_pointer* list) {
    node_pointer current;
    while (*list != NULL) {
        current = *list;
        *list = (*list)->next;
        free(current);
    }
    printf("List erased successfully\n");
}

int main() {
    // Δημιουργία λίστας
    node_pointer list = NULL;

    // Πρόσθεση μεταβλητών στη λίστα
    add_variable_if_not_in_list(&list, "a", "int");
    add_variable_if_not_in_list(&list, "b", "int");
    add_variable_if_not_in_list(&list, "c", "float");
    add_variable_if_not_in_list(&list, "a", "int");
    add_variable_if_not_in_list(&list, "e", "int");
    add_variable_if_not_in_list(&list, "f", "float");
    add_variable_if_not_in_list(&list, "g", "int");
    add_variable_if_not_in_list(&list, "h", "float");
    add_variable_if_not_in_list(&list, "i", "float");

    // Εμφάνιση των στοιχείων της λίστας
    show_list(list);

    // Διαγραφή της λίστας
    delete_list(&list);

    return 0;
}
