#include <stdio.h>

#define MAX_STUDENTS 5 // Ορισμός του μέγιστου αριθμού φοιτητών
#define MAX_ASSIGNMENTS 4 // Ορισμός του μέγιστου αριθμού εργασιών ανά φοιτητή

// Συνάρτηση για τον υπολογισμό του τελικού βαθμού
float calculateFinalGrade(float sumAssignments, int totalExamsGrade) {
    return 0.30 * (sumAssignments / MAX_ASSIGNMENTS) + 0.70 * totalExamsGrade;
}

int main() {
    system("chcp 65001>nul"); 
    //Δήλωση μεταβλητών 
    int studentID[MAX_STUDENTS], eligibleForExams[MAX_STUDENTS];
    float grades[MAX_STUDENTS][MAX_ASSIGNMENTS], finalExamGrade[MAX_STUDENTS] = {0}, resitExamGrade[MAX_STUDENTS] = {0}, finalGrade[MAX_STUDENTS] = {0};
    int i, j, deliveredAssignments; 
    float sumAssignments, gradeInput; 

    // Εισαγωγή δεδομένων για κάθε φοιτητή
    for (i = 0; i < MAX_STUDENTS; i++) {
        printf("AM %dου φοιτητή: ", i + 1);
        scanf("%d", &studentID[i]);
        // Έλεγχος για τον τετραψήφιο ΑΜ
        while (studentID[i] < 1000 || studentID[i] > 9999) {
            printf("Λάθος Τιμή! Εισάγετε ξανά τον ΑΜ του φοιτητή: ");
            scanf("%d", &studentID[i]);
        }

        sumAssignments = 0;
        deliveredAssignments = 0;
        // Εισαγωγή και έλεγχος βαθμών για κάθε εργασία
        for (j = 0; j < MAX_ASSIGNMENTS; j++) {
            printf("Βαθμός %d Εργασίας (0-10 ή -1 για μη υποβολή):", j + 1);
            scanf("%f", &gradeInput);
            // Έλεγχος εγκυρότητας βαθμού
            while ((gradeInput < -1 || gradeInput > 10) || (gradeInput != -1 && ((int)(gradeInput * 10) % 10 != 0))) {
                printf("Λάθος τιμή! Εισάγετε ξανά τον βαθμό της %dης Εργασίας: ", j + 1);
                scanf("%f", &gradeInput);
            }
            grades[i][j] = gradeInput;
            // Υπολογισμός συνολικού βαθμού και εργασιών
            if (gradeInput != -1) {
                sumAssignments += gradeInput;
                deliveredAssignments++;
            }
        }
        // Καθορισμός εξετάσεων
        eligibleForExams[i] = (deliveredAssignments >= 3 && sumAssignments >= 20) ? 1 : 0;
    }

    // Εισαγωγή βαθμών τελικών και επαναληπτικών εξετάσεων για φοιτητές
    for (i = 0; i < MAX_STUDENTS; i++) {
        if (eligibleForExams[i] == 1) {
            printf("Εισαγωγή Βαθμού Τελικών Εξετάσεων (0-10) για τον φοιτητή με ΑΜ %d: ", studentID[i]);
            scanf("%f", &finalExamGrade[i]);
            // Εισαγωγή βαθμού επαναληπτικών εάν ο βαθμός τελικών είναι κάτω από 5
            if (finalExamGrade[i] < 5) {
                printf("Εισαγωγή Βαθμού Επαναληπτικών Εξετάσεων (0-10) για τον φοιτητή με ΑΜ %d: ", studentID[i]);
                scanf("%f", &resitExamGrade[i]);
            }
        }
    }

    // Υπολογισμός και εμφάνιση του τελικού βαθμολογίου
    printf("----- ΒΑΘΜΟΛΟΓΙΟ (ΠΛΗ10 - Ακ.Ετός 2023-2024 - Τμήμα: ΗΛΕ86) -----\n");
    printf(" ΑΜ | ΓΕ1 | ΓΕ2 | ΓΕ3 | ΓΕ4 | ΔΣΕ | Τελική | Επαναλ | Βαθμός |\n");
    for (i = 0; i < MAX_STUDENTS; i++) {
        printf("%4d |", studentID[i]);
        for (j = 0; j < MAX_ASSIGNMENTS; j++) {
            // Εκτύπωση βαθμών εργασιών ή κενού αν δεν έχει παραδοθεί
            if (grades[i][j] != -1) {
                printf(" %.1f |", grades[i][j]);
            } else {
                printf("    |");
            }
        }
        // Εκτύπωση βαθμών εξετάσεων και τελικού βαθμού
        printf(" %d |", eligibleForExams[i]);
        if (finalExamGrade[i] > 0) {
            printf(" %.1f |", finalExamGrade[i]);
        } else {
            printf("     |");
        }
        if (resitExamGrade[i] > 0) {
            printf(" %.1f |", resitExamGrade[i]);
        } else {
            printf("      |");
        }
        // Υπολογισμός και εκτύπωση του τελικού βαθμού
        if (eligibleForExams[i] && (finalExamGrade[i] >= 5 || resitExamGrade[i] >= 5)) {
            finalGrade[i] = calculateFinalGrade(sumAssignments, (finalExamGrade[i] >= 5) ? finalExamGrade[i] : resitExamGrade[i]);
            printf(" %.2f |\n", finalGrade[i]);
        } else {
            printf("       |\n");
        }
    }
    return 0;
}
