#include <stdio.h>
#include <stdlib.h>

#define N 4

void fillBoard(int board[N][N]);
void printBoard(int board[N][N]);
void printFirstAndLastRow(int board[N][N]);
int sumMainDiagonal(int board[N][N]);

int main()
{
    system("chcp 65001>null");
    int X[N][N];

    // Ολοκληρώνει τον πίνακα βάση των υπολογισμών που έχουν ζητηθεί
    fillBoard(X);

    // Τυπώνει ολόκληρο τον πίνακα
    printBoard(X);

    // Τυπώνει την πρώτη και την Ν-οστή γραμμή
    printFirstAndLastRow(X);

    // Υπολογίζει και εκτυπώνει την κύρια Διαγώνιο
    printf("Το άθροισμα της κύριας Διαγωνίου είναι: %d\n", sumMainDiagonal(X));

    return 0;
}

void fillBoard(int board[N][N])
{
    // Ζητάει από τον χρήστη να κατχωρήσει τους αριθμούς της πρώτης γραμμής
    for (int i = 0; i < N; i++)
    {
        do
        {
            printf("Καταχωρήστε αριθμούς για την πρώτη γραμμή [0][%d] (-10 to 10): ", i);
            scanf("%d", &board[0][i]);
        } while (board[0][i] < -10 || board[0][i] > 10);
    }

    // Συμπληρώνει τον υπόλοιπο πίνακα
    for (int i = 1; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            board[i][j] = board[0][j] * (i + 1);
        }
    }
}

void printBoard(int board[N][N])
{
    // Τυπώνει τον πίνακα
    printf("\nΈγινε εισαγωγή πίνακα \n Εμφάνιση πίνακα:\n");
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            printf("[%d][%d]: %d ", i, j, board[i][j]);
        }
        printf("\n");
    }
}

void printFirstAndLastRow(int board[N][N])
{
    // Πρώτη Γραμμή
    printf("Εμφάνιση στοιχείων πρώτης γραμμής:\n");
    for (int i = 0; i < N; i++)
    {
        printf("[%d][%d]: %d ", 0, i, board[0][i]);
    }
    printf("\n");

    // Τελευταία γραμμη (Ν-οστή)
    printf("Εμφάνιση στοιχείων τελευταίας γραμμής:\n");
    for (int i = 0; i < N; i++)
    {
        printf("[%d][%d]: %d ", N - 1, i, board[N - 1][i]);
    }
    printf("\n");
}

int sumMainDiagonal(int board[N][N])
{
    // Υπολογίζει την Κύρια Διαγώνιο
    int sum = 0;
    for (int i = 0; i < N; i++)
    {
        sum += board[i][i];
    }
    return sum;
}
