#include <stdio.h>
#include <stdlib.h>

int main()
{
    system("chcp 65001>null");
    int N;
    double S = 0;

    // Διάβασμα του N
    printf("εισάγετε έναν αριθμό N μεταξύ 1 και 12:");
    scanf("%d", &N);

    // Έλεγχος για την τιμή του N
    while (N < 1 || N >= 12)
    {
        printf("εισάγετε έναν αριθμό N μεταξύ 1 και 12:");
        scanf("%d", &N);
    }

    // Υπολογισμός του result
    S = N / (2.0 * N - 1);

    // Εμφάνιση αποτελεσμάτων
    printf("το S είναι: %f\n", S);

    return 0;
}
