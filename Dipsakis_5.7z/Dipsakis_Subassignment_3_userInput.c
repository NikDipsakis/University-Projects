#include <stdio.h>
#include <stdlib.h>

void fillBoard(int **board, int N);
void printBoard(int **board, int N);
void printFirstAndLastRow(int **board, int N);
int sumMainDiagonal(int **board, int N);

int main()
{
    int N;
    system("chcp 65001>null");
    printf("Εισάγετε το μέγεθος του πίνακα N: ");
    scanf("%d", &N);

    int **X = (int **)malloc(N * sizeof(int *));
    for (int i = 0; i < N; i++)
        X[i] = (int *)malloc(N * sizeof(int));

    if (X == NULL)
    {
        printf("Η δέσμευση μνήμης απέτυχε\n");
        return 1;
    }

    fillBoard(X, N);
    printBoard(X, N);
    printFirstAndLastRow(X, N);
    printf("Το άθροισμα της κύριας Διαγωνίου είναι: %d\n", sumMainDiagonal(X, N));

    for (int i = 0; i < N; i++)
        free(X[i]);
    free(X);

    return 0;
}

void fillBoard(int **board, int N)
{
    for (int i = 0; i < N; i++)
    {
        do
        {
            printf("Καταχωρήστε αριθμούς για την πρώτη γραμμή [%d] (-10 to 10): ", i);
            scanf("%d", &board[0][i]);
        } while (board[0][i] < -10 || board[0][i] > 10);
    }

    for (int i = 1; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            board[i][j] = board[0][j] * (i + 1);
        }
    }
}

void printBoard(int **board, int n)
{
    printf("\nΈγινε εισαγωγή πίνακα \n Εμφάνιση πίνακα:\n");
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            printf("[%d][%d]: %d ", i, j, board[i][j]);
        }
        printf("\n");
    }
}

void printFirstAndLastRow(int **board, int n)
{
    printf("Εμφάνιση στοιχείων πρώτης γραμμής:\n");
    for (int i = 0; i < n; i++)
    {
        printf("[%d]: %d ", i, board[0][i]);
    }
    printf("\n");

    printf("Εμφάνιση στοιχείων τελευταίας γραμμής:\n");
    for (int i = 0; i < n; i++)
    {
        printf("[%d]: %d ", i, board[n - 1][i]);
    }
    printf("\n");
}

int sumMainDiagonal(int **board, int n)
{
    int sum = 0;
    for (int i = 0; i < n; i++)
    {
        sum += board[i][i];
    }
    return sum;
}
