#include <stdio.h>
#include <stdlib.h>

int main()
{
    system("chcp 65001>null");
    float maxTemps[10], totalTemp = 0, avgTemp, maxTemp = 20;
    int i, citiesAbove40 = 0, maxTempCityIndex;
    float temp;

    for (i = 0; i < 10; i++)
    {
        printf("Εισάγετε την μέγιστη θερμοκρασία για την πόλη %d: ", i + 1);
        scanf("%f", &temp);

        // Β.1 // Αμυντικός προγραμματισμός για τις τιμές των θερμοκρασιών
        while (temp < 20 || temp > 50)
        {
            printf("Λάθος τιμή. Εισάγετε τιμή μεταξύ 20 και 50: ");
            scanf("%f", &temp);
        }

        maxTemps[i] = temp;
        totalTemp += temp;

        // Εντόπιζουμε τις πόλεις ανω των 40 και τισ προσθέτουμε
        if (temp > 40)
        {
            citiesAbove40++;
        }
        // Πέρναμε μία προς μία τις πόλεις και κρατάμε την μέγιστη
        if (temp > maxTemp)
        {
            maxTemp = temp;
            maxTempCityIndex = i + 1; // Αποθηκεύουμε την θέση της πόλης με την μέγιστη θερμοκρασία
        }
    }

    // Βρίσκουμε τον μέσο όρο των θερμοκρασιών
    avgTemp = totalTemp / 10;

    // Τυπώνουμε τα αποτελεσματα
    // Β.2.
    printf("Το μέσο όρο των θερμοκρασιών είναι: %.2f\n", avgTemp);
    // Β.3.
    printf("Οι πόλεις με θερμοκρασία άνω των 40 είναι : %d\n", citiesAbove40);
    // Β.4
    printf("Η μεγαλύτερη θερμοκρασία ήταν %.2f στην πόλη με τον αριθμό %d\n", maxTemp, maxTempCityIndex);

    return 0;
}