walkers = {'George': [58, 60, 62], 'James': [60, 55, 70], 'Mary': [59, 61, 63]}
walk_info = {'days': ['1/10/23', '8/10/23', '15/10/23']}

while True:
    date = input("Δώσε την ημερομηνία: ")
    
    if date in walk_info['days']:
        date_index = walk_info['days'].index(date)
        for walker, time in walkers.items():
            print(f"Ο βαδιστής {walker} έκανε την {date} χρόνο {time[date_index]}'")
        break
    else:
        print("Δόθηκε άκυρη ημερομηνία. Παρακαλώ δώστε μία έγκυρη ημερομηνία.")
