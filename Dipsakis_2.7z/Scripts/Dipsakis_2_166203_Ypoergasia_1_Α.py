walkers = {'George':[58, 60, 62], 'James':[60, 55, 70], 'Mary':[59, 61, 63]}

# α
for walker in walkers:
    print(walker)

# β
for walker, times in walkers.items():
    print(f"{walker} : {times}")

# γ
for times in walkers.values():
    print(times)

# δ
for times in walkers.values():
    print(min(times))

# ε
for times in walkers.values():
    print(max(times))

# στ
for times in walkers.values():
    average_time = sum(times) / len(times)
    print(f"{average_time:.1f}")