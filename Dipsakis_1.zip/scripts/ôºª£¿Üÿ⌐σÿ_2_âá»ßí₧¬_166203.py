while True:
    star = "*"
    dot = "."
    n_str = input("Δώστε το n (1-20): ")

    if not n_str:
        print("Τέλος προγράμματος.")
        break

    n = int(n_str)

    if n < 1 or n > 20:
        print("Ο αριθμός(n) πρέπει να είναι αναμεσα στο 1-20")
        continue

    for i in range(1, n + 1):
        starLine = star * i
        dotLine = dot * 2 * (n - i)
        completeLine = starLine + dotLine + dot + starLine
        print(completeLine)
