s = "abcdefgh"
# α
print(s[:])
# β
print(s[0:1])
# γ
print(s[-1])
# δ
print(s[2:5])
# ε
print(s[::-1])
# στ
print(s[::2])
# ζ
print(s[1::2])
# η
print(s[-1::-2])
# θ
print(s[-2::-2])
# ι
print(s[::7])
